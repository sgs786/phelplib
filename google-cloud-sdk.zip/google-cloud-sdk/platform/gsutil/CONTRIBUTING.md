See
https://cloud.google.com/storage/docs/gsutil/addlhelp/ContributingCodetogsutil
for details on how to contribute code changes.
