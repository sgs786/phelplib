def user = "pythonhol"
def pw = "welcome"
def connect_string = "localhost/orclpdb1"
